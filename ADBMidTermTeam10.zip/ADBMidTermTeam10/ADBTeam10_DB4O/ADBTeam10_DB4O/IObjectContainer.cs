﻿namespace ADBTeam10_DB4O
{
    public interface IObjectContainer
    {
    }
}