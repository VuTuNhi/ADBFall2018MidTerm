﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Db4objects.Db4o;

namespace ADBTeam10_DB4O
{
    class Program
    {
        static void Main(string[] args)
        {
            //Mở 1 db mới
            IObjectContainer db = Db4oEmbedded.OpenFile("4201104158_CourseManager");
        }
        public static object Db4oEmbedded { get; private set; }

        //nhập danh sách tối thiểu 5 môn học (MonHoc) và lưu xuống CSDL. 

        public static void NhapMonHOc(IObjectContainer db)
        {
            MonHoc m1 = new MonHoc(01, "Cơ sở dữ liệu", null, "CNTT", null, 03);
            db.Store(m1);
            MonHoc m2 = new MonHoc(02, "Cơ sở dữ liệu nâng cao", null, "CNTT", 01, 03);
            db.Store(m2);
            MonHoc m3 = new MonHoc(03, "Bảo mật Cơ sở dữ liệu", null, "CNTT", 01, 03);
            db.Store(m3);

        }
        public static void listResult(IObjectSet result)
        {
            Console.WriteLine(result.Count);
            foreach (object item in result)
            {
                Console.WriteLine(item);
            }
        }
        public static void RetrieveAllEmps(IObjectContainer db)
        {
            IObjectSet result = db.QueryByExample(typeof(MonHoc));
            listResult(result);//Xuat du lieu
        }
    }
}
    }
}
